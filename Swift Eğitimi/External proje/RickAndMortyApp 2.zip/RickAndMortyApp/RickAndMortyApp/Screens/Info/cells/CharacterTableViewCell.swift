//
//  CharacterTableViewCell.swift
//  RickAndMortyApp
//
//  Created by obss on 14.05.2022.
//

import UIKit
import Kingfisher

class CharacterTableViewCell: UITableViewCell {

    
    @IBOutlet weak var characterImageView: UIImageView!{
        didSet{
            characterImageView.layer.cornerRadius = 30
        }
    }
  
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var initailLabel: UILabel!
 
    
   
    
    func configure(character: CharactersDetail){
        nameLabel.text = character.name
        initailLabel.text = character.status
        statusLabel.text = character.species
        characterImageView.kf.setImage(with: character.image)
    }
}

  
