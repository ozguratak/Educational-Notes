//
//  CharactersInfoViewController.swift
//  RickAndMortyApp
//
//  Created by obss on 14.05.2022.
//

import UIKit

class CharactersInfoViewController: UIViewController {

    @IBOutlet weak var tableWiev: UITableView!{ //table view için outleti tanımlıyoruz.
        didSet{ //tableview yüklendiğinde;
            tableWiev.delegate = self // kendine delege et
            tableWiev.dataSource = self // kendi data sourceunu kullan
            tableWiev.register(UINib(nibName: String(describing: CharacterTableViewCell.self), bundle: nil), forCellReuseIdentifier: String(describing: CharacterTableViewCell.self)) //benim tanımaldığım hücre yapısını register et. 
            
        }
    }
    //self.characters = response.results ?? []
    private let characterService = CharacterServices()
    var characters: [CharactersDetail] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        characterService.getAllCharacters { result in
            switch result {
            case .success(let response):
                self.characters = response.results ?? []
                self.tableWiev.reloadData()
            case .failure(let error):
                print(error)
            }
            
        }
        
    }
    

}
extension CharactersInfoViewController: UITableViewDataSource, UITableViewDelegate { // Table view için kaç adet satır sıralanacağını belirledik.
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return characters.count
    
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell { // table view içerisinde tasarladığımız cell'leri çağırdık ve nereden nasıl kullanılacağını ifade ettik.
         let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: CharacterTableViewCell.self), for: indexPath) as! CharacterTableViewCell

        cell.configure(character: characters[indexPath.row])
    
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) { // cell'lere dokunduğumuzda ne yapacağını anlattık. burada oluşturduğumuz detay sayfasını çağırıyoruz ve yeni bir sayfada açtırıyoruz. aynı işlemi performsegue kullanarakta yapabilirdik ancak hata yapmaya çok müsait bir yapı olduğundan tercih etmedik. bu fonksiyon içerindeki indexpath parametresini indexpath row değerine bir değer atayarak her dokunmada başka bir sayfaya gitmesini de sağlayabilirdik.
       
        if let detailVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: String(describing: CharactersDetailViewController.self)) as? CharactersDetailViewController{
            detailVC.idOfCharacter = characters[indexPath.row].id //id datası gönderilecek
            print (detailVC.numberOfCharacter)
            self.navigationController?.pushViewController(detailVC, animated: true)
            
        }
    }
}


