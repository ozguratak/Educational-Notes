//
//  Network.swift
//  RickAndMortyApp
//
//  Created by obss on 14.05.2022.
//

import Foundation
struct Network {
// Tüm network isteklerimiz için bir yapı yaratıyoruz. temel olarak beklediğimiz şey bir perform request isteklerini atması
    
   private let session = URLSession.shared
// perform request istekleri session üstünden attığı için konfigürasyonları ortak yapması için bunu tanımlıyoruz. ilerde aldığımız linkin başka yerlerde rahatça kullanılması için sessionı shared tasarlıyoruz.ancak private olan bu değişken dışarıdan bir müdahaleye kapalı olarak tasarlanıyor. şuan bu blokta efektif kullanılmasada ilerde lazım olur
    
    func performRequest<T: Codable>(request: URLRequest, completion: @escaping (Result<T, NetworkError>) -> Void ) {
// performRequest fonksiyonu sayesinde URL için task session gibi işlemleri tanımlıyoruz. ancak burada dataTask yapısı bir URL request istiyor bu fonksiyonu global olarak kullanbilmek ve her iş için ayrı bir dataTask yaratmamak için URLRequest değişkenini fonksiyonu çağrırken parametre olarak girdiriyoruz.
        
        // completion tanımlarken bir blok yapısı tanımlıyoruz. Temel bir blok yapısı "() -> Void" olarak ifade ediliyor. peki bu blok bize ne dönecek? bu blok bize Network > Model klasörü içerisinde tanıladığımız modellerimiz dönecek. her serviste başka bir şey dönebilir. Burada birden çok modelimiz var ama hepsinin ortak özelliği codable olması o yüzden bizde fonksiyonumuzun başına bir "Generic Type / Ortak tip " tanımı yapıyoruz. nedir ortak özelliğimiz? tüm modellerimizin codable olması. <T: Codable> ifadesini kullanarak modellerimizin ortak yapısının codable olması gerçeğini ifade ettik.
        //!!T'NİN NE OLDUĞUNU BİZ BİLMİYORUZ. FONKSİYONU ÇAĞIRAN YAPI BUNU BELİRLEYECEK!!
        
        // completion'ın bir diğer yapısı ne döneceğini ifade etmek. Burada biz T: codable olan bir yapı dönmesini söylüyoruz. Swift bu tarz network işlemleri için bir Result enumu barındırıyor. 1. parametre success olma durumu. Success olursa codable olan T'yi dön diyoruz. 2. parametre ise Error durumu yani T nin codable olmaması durumu. bu durumda ise basitçe error dönecek.
        
       
       let task = session.dataTask(with: request) { data, response, error in
//burada verdiğimiz url üzerinden datayı alıyoruz. bize data response veya error dönebilir. Bu durumda bu outputları biyere dönmemiz lazım. bunun için delegate yöntemi kullanabiliriz ama burada compleation kullandık. Completion kullanma sebebimiz delegate yöntemine göre daha hızlı ve az uğraştırıyor olması network işlemleri çok sık kullanılıyor ve az uğraştırması gerekiyor, o yüzden performRequestin içine bir completion tanımladık 2. paragrafta completion tanımı devam ediyor.
           DispatchQueue.main.async { //URL Session kullandığımız için datayı yüklememiz gerekiyor. Session kullandıracağımız heryerde bunu yazmamak için buraya ekliyoruz. Normalde güvenlik açısından her completion çağrılan yerde bunu yazmak daha doğru şu anda kim tetiklerse tetiklesin sürekli data load edecek. 
               if let data = data { // eğer data geldiyse
                   do{
                       let model = try JSONDecoder().decode(T.self, from: data) // model dönebilmesi için sana data olarak delen paketi try methodu ile (jsondecoderin bir metodu) jsondecoder fonksiyonu ile T olarak tanımlanmış olan GenericType'ı çözümle ve döndür.
                       completion(.success(model)) // eğer model başarılı yani data olarak dönüyorsa performRequest completionı başarılı demektir ve model döner.
                   }
                   catch{ // hata yakala
                   completion(.failure(.decodingError)) //model fail ederse error olarak dönüyorsa bu errorü decode et ve network error enumı içerisinden eşleyip bana error dön.
                   }
               }
                   else if error != nil { // eğer urlsession data taskı error dönüyorsa, session hatası bas
                       completion(.failure(.sessionError))
                   }
                   else { //bilinmeyen hata varsa unknown error bas
                       completion(.failure(.unknownError))
                   }
               }
           }
       
        task.resume() // task askıya alında dahi işlemi devam ettirir. yani fonksiyonu çalıştırır.
        
    }
}
    
enum NetworkError: Error {
    case decodingError
    case sessionError
    case unknownError
}

