//
//  AllCharacters.swift
//  RickAndMortyApp
//
//  Created by obss on 14.05.2022.
//

import Foundation
struct AllCharacters: Codable{
    
    let results: [CharactersDetail]?
}
