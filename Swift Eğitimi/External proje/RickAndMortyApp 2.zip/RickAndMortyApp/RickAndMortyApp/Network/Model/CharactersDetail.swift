//
//  JSONDataModel.swift
//  RickAndMortyApp
//
//  Created by obss on 14.05.2022.
//

import Foundation
struct CharactersDetail: Codable{
    
    let id: Int?
    let name: String?
    let status: String?
    let species: String?
    let type: String?
    let gender: String?
    let origin: Origin?
    let location: Location?
    let image: URL?
    let episode: [String]?
    let url: String?
    

struct Origin: Codable{
    let name: String?
    let url: String?
}
struct Location: Codable{
    let name: String?
    let url: String?
}

}
