//
//  CharacterServices.swift
//  RickAndMortyApp
//
//  Created by obss on 14.05.2022.
//

import Foundation

/*protocol CharacterServicesProtocol { //bir protokol yaratark dışarıdan müdahaleyi iyice kapatmış ve netleştirmiş olduk.
    
    func getAllCharacters(completion: @escaping (Result <AllCharacters, NetworkError>) -> Void )
    func getCharacter(id: Int, completion: @escaping (Result <CharactersDetail, NetworkError>) -> Void)
    
}*/

struct CharacterServices{ // Network katmanının üstüne bir katman daha atıyoruz. amacımız network çözümlememizin ortalıkta dolaşmasına müsade etmemek. tanımladığımız fonksitonlar performrequest fonksiyonunu çağıracak. perform request fonksiyonu kendi içinde bir completiona sahipti ancak generic type'ı boş bırakılmıştı ve sadece fail için network error tanımlıydı. şimdi aşağıda fonksiyonları yaratacağız ve generic type a uygun modellerle birlikte ihtiyacımız olan urlleri implement ederek sadece characterservices.getallcharacters diyerek istediğimiz verileri basitçe managerda alabileceğiz. yani artık T dediğimiz bilinmeyen parametreler fonksiyona bağlı olarak tanımlanmış olacak.
    
    private let network = Network() // kendi içersiinde private olarak networkü biliyor.
    
    func getAllCharacters(completion: @escaping (Result <AllCharacters, NetworkError>) -> Void ) { //ilk methodum getAllCharacters. yapacağı işlem belli sadece kendi içinde request bilmesi yeterli. Bloğumuzda içerde escape bişey çapırıyoruz o yüzden @escaping var
        
        var urlRequest = URLRequest(url: URL(string: "https://rickandmortyapi.com/api/character")!) //url requesti tanımlıyoruz, burada zaten getallcharacters fonksiyonu sadece tek bir iş yapacağı için kendine ait bir urle sahip
        urlRequest.httpMethod = "GET"
        network.performRequest(request: urlRequest, completion: completion) // tanımladığımız url'i network içindeki performRequest fonksiyonuna parametreleri olan request için burada yarattığımız url requesti veriyoruz. completionımız fonksiyon içinde tanımlı olup AllCharacters modelinde Network errorü ile birlikte dönüyor. yani burada tüm completionları birbirine bağladık.
    }
    func getCharacter(id: Int, completion: @escaping (Result <CharactersDetail, NetworkError>) -> Void) { // gene get all characters fonksiyonund aolduğu gibi bir metod tanımladık ancak bu metod "id" parametresi talep ediyor. completion aynı şekilde CharactersDetail modelini ve network errorü döndürüyor.
        
        var urlRequest = URLRequest(url: URL(string: "https://rickandmortyapi.com/api/character/\(id)")!) //bu fonksiyonda kendi içinde kendine air url e sahip ve perform request için urli tanımladık.
        urlRequest.httpMethod = "GET"
        network.performRequest(request: urlRequest, completion: completion) // network dosyası içindeki perform request fonksiyonumuz artık url'ini öğrendi, completion olarak getcharacters fonksiyonunun completionını tanımladık. şu anda characterservices.getcharacters dediğimizde bu fonksiyonumuz; kendi urlini performRequeste gönderecek daha sonra completion olarakda getcharacters(T) fonksiyonumuzda belirtilen model olarak charactersDetaili alacak ve default olan fail için networkerror bloğunu çağırarak performrequeste ekleyecek.
    }
    
    
}

